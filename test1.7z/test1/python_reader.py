""" PY READER FROM ESP """
# Written by Junicchi - https://github.com/Kebablord

from time import sleep
import urllib.request
import codecs
url = "Adresse IP"  # ESP's IP, ex: http://192.168.102/ (Check serial console while uploading the ESP code, the IP will be printed)

def get_data():
    global data

    n = urllib.request.urlopen(url).read() # get the raw html data in bytes (sends request and warn our esp8266)

    data = n

MonTest = True
while MonTest == True:
    get_data()
    print(data)
    MonTest = False
